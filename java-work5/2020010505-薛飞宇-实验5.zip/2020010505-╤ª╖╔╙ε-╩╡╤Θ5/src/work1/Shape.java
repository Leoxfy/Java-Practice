package work1;

public abstract class Shape {
	abstract double getarea();
}
