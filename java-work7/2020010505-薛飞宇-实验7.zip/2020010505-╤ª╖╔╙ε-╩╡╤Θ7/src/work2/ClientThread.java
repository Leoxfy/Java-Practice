package work2;

public class ClientThread implements Runnable{
	
	@Override
	public void run() {
		
	}

}
