package work3;

public class Product {
	int name;
	public Product(int i) {
		// TODO Auto-generated constructor stub
		name = i;
	}
}
